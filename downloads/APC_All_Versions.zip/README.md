APC saved program versions

These are preserved calculator program snapshots. For normal installation, use APC_Complete.zip and START_HERE.md. Do not merge version folders.
