Evo keyboard repair - E-Field Studio v3 patch

Send BOTH .py files in PATCH together using TI Connect Evo, with replacement enabled. Restart Python, then run EFKEY. Press and RELEASE each requested key: UP, DOWN, LEFT, RIGHT, ENTER, CLEAR. Then complete the DOWN/ENTER menu test. It prints PASS: hardware navigation and opens EFIELD with your measured bindings. Bindings last for this Python session. Run EFKEY again to recalibrate after restarting, or run EFIELD to use the repaired built-in defaults.

The previous version recognized CE Python codes but omitted Evo keypad codes. This repair supports Evo, CE, and named-string keys, prefers get_key(1) on Evo, and ignores unknown events. EFKEY learns the actual codes instead of depending on a hard-coded mapping.

33 desktop test groups passed. Physical keyboard success is confirmed only when the EFKEY menu test passes on your calculator.
