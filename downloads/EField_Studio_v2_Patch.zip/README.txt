E-Field Studio v2 patch with Evo keyboard repair

Unzip, select all eight .py files in PATCH together, and send them in one TI Connect Evo batch. Enable replacement of matching names. Restart the Python shell, run EFCHK (expect PASS: 12 physics + 2 UI), restart once more, then run EFIELD.

UP/DOWN selects; ENTER opens. LEFT/RIGHT changes pages. In a guide ENTER/RIGHT advances, LEFT returns, CLEAR/0 exits. Full labels wrap and no longer require CLEAR then ENTER.

Desktop verification: 33 test groups passed. If keys still need calibration, also install EFKEY from the v3 keyboard patch and run EFKEY instead of EFIELD. Physical key handling and rendering require an on-calculator check.
